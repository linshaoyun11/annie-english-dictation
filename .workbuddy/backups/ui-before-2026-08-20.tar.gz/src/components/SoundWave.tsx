interface SoundWaveProps {
  active: boolean;
  onClick?: () => void;
}

const BARS = [0.4, 0.9, 0.55, 1, 0.65, 0.85, 0.45, 0.75, 0.5, 0.95, 0.6, 0.8, 0.4, 0.7];

export default function SoundWave({ active, onClick }: SoundWaveProps) {
  return (
    <button
      type="button"
      onMouseDown={(e) => e.preventDefault()}
      onClick={onClick}
      aria-label={active ? "正在朗读，点击重听" : "点击播放朗读"}
      className="flex h-24 w-44 items-end justify-center gap-[5px] rounded-2xl transition-colors select-none"
      style={{ cursor: "pointer" }}
    >
      {BARS.map((h, i) => (
        <span
          key={i}
          className="w-[5px] rounded-full"
          style={{
            height: `${Math.round(h * 40) + 8}px`,
            backgroundColor: "#534AB7",
            animation: active
              ? `waveBar 1.1s ease-in-out ${i * 0.09}s infinite alternate`
              : "none",
            opacity: active ? 1 : 0.3,
            transition: "opacity .3s",
          }}
        />
      ))}
    </button>
  );
}
