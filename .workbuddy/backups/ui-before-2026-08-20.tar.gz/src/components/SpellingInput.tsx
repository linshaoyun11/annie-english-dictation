import { useEffect, useMemo, useRef, useState } from "react";

interface WordGroup {
  letters: string[]; // 需要输入的字母（保留原大小写）
  suffix: string; // 词尾标点（预填显示，不需输入）
}

interface SpellingInputProps {
  target: string;
  resetKey: string;
  onComplete: () => void;
  onFirstInput?: () => void;
  /** 本题第一次拼错字母时触发（用于统计"曾经拼错"的词条） */
  onFirstMistake?: () => void;
  /** 递增此值会触发自动揭示正确答案 */
  revealSignal?: number;
  /** 本题累计拼错字母达到 5 次时回调（整题只触发一次） */
  onStrike5?: () => void;
}

function parseTarget(target: string): WordGroup[] {
  return target
    .split(" ")
    .filter(Boolean)
    .map((w) => {
      const letters: string[] = [];
      let i = 0;
      while (i < w.length && /[a-zA-Z]/.test(w[i])) {
        letters.push(w[i]);
        i++;
      }
      return { letters, suffix: w.slice(i) };
    })
    .filter((g) => g.letters.length > 0);
}

function isLetter(c: string) {
  return /^[a-zA-Z]$/.test(c);
}

export default function SpellingInput({
  target,
  resetKey,
  onComplete,
  onFirstInput,
  onFirstMistake,
  revealSignal = 0,
  onStrike5,
}: SpellingInputProps) {
  const groups = useMemo(() => parseTarget(target), [target]);
  const totalLetters = useMemo(
    () => groups.reduce((s, g) => s + g.letters.length, 0),
    [groups]
  );
  const allLetters = useMemo(
    () => groups.flatMap((g) => g.letters),
    [groups]
  );

  const [typed, setTyped] = useState<string[]>([]);
  const [done, setDone] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const firstInputFired = useRef(false);
  // 守卫：确保同一题的 onComplete 只触发一次（防 StrictMode/并发渲染重复加分）
  const completedRef = useRef(false);
  // 已输入的字母数（ref 同步，避免多字符快速输入时闭包 stale）
  const typedLenRef = useRef(0);
  // 本题累计拼错次数与"已达 5 次"守卫
  const errorCountRef = useRef(0);
  const strike5FiredRef = useRef(false);

  useEffect(() => {
    setTyped([]);
    setDone(false);
    setRevealed(false);
    firstInputFired.current = false;
    completedRef.current = false;
    typedLenRef.current = 0;
    errorCountRef.current = 0;
    strike5FiredRef.current = false;
    inputRef.current?.focus();
  }, [resetKey]);

  // 焦点常驻：答题中误触页面任意位置（含提示卡片、按钮等）后自动把焦点还给输入框
  // 点击"我不会"/"记住了"等按钮时，按钮 onClick 先执行、冒泡到 document 后才 focus，
  // 因此不影响按钮功能；revealed/done 状态下不抢焦点，避免干扰答案展示与下一题按钮
  useEffect(() => {
    const onDocClick = () => {
      if (done || revealed) return;
      inputRef.current?.focus();
    };
    document.addEventListener("click", onDocClick);
    return () => document.removeEventListener("click", onDocClick);
  }, [done, revealed]);

  // 外部触发"我不会"/错误满 5 次：自动填入正确答案（不算答对，不加分）
  useEffect(() => {
    if (revealSignal > 0) {
      completedRef.current = true; // 阻止下方完成检测误触发 onComplete
      typedLenRef.current = totalLetters;
      setTyped([...allLetters]);
      setDone(true);
      setRevealed(true);
      inputRef.current?.blur();
    }
  }, [revealSignal, allLetters, totalLetters]);

  // 完成检测：typed 变化时校验，全部正确则触发 onComplete（纯副作用，不在 updater 内）
  useEffect(() => {
    if (done || completedRef.current) return;
    if (typed.length !== totalLetters) return;
    const allCorrect = typed.every(
      (ch, i) => ch.toLowerCase() === allLetters[i].toLowerCase()
    );
    if (!allCorrect) return;
    completedRef.current = true;
    setDone(true);
    if (navigator.vibrate) navigator.vibrate([40, 60, 40]);
    inputRef.current?.blur();
    onComplete();
  }, [typed, totalLetters, allLetters, done, onComplete]);

  const pushLetter = (c: string) => {
    if (done || completedRef.current) return;
    if (!isLetter(c)) return;
    const idx = typedLenRef.current;
    if (idx >= totalLetters) return;
    const targetChar = allLetters[idx];
    // 拼错计数（累计只增不减）：首次拼错通知上层统计；满 5 次自动加入重点记忆
    if (c.toLowerCase() !== targetChar.toLowerCase()) {
      if (errorCountRef.current === 0) onFirstMistake?.();
      errorCountRef.current += 1;
      if (errorCountRef.current >= 5 && !strike5FiredRef.current) {
        strike5FiredRef.current = true;
        onStrike5?.();
      }
    }
    typedLenRef.current = idx + 1;
    setTyped((prev) => {
      if (prev.length >= totalLetters) return prev;
      return [...prev, c];
    });
    if (!firstInputFired.current) {
      firstInputFired.current = true;
      onFirstInput?.();
    }
  };

  const popLetter = () => {
    if (done) return;
    if (typedLenRef.current > 0) typedLenRef.current -= 1;
    setTyped((prev) => prev.slice(0, -1));
  };

  const handleInput = (e: React.FormEvent<HTMLInputElement>) => {
    const el = e.currentTarget;
    const val = el.value;
    el.value = "";
    for (const c of val) {
      if (isLetter(c)) pushLetter(c);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      e.preventDefault();
      popLetter();
    }
  };

  let letterIdx = -1;

  return (
    <div
      className="relative w-full select-none"
      onClick={() => !done && inputRef.current?.focus()}
    >
      <input
        ref={inputRef}
        className="absolute opacity-0 pointer-events-none"
        style={{ top: 0, left: 0, width: 1, height: 1 }}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="characters"
        spellCheck={false}
        onInput={handleInput}
        onKeyDown={handleKeyDown}
        value=""
        onChange={() => {
          /* value 由 onInput 处理 */
        }}
      />
      <div
        className={`flex flex-wrap items-end justify-center gap-x-6 gap-y-5 ${
          totalLetters > 18 ? "px-2" : ""
        }`}
      >
        {groups.map((g, gi) => (
          <div key={gi} className="flex items-end" style={{ gap: 6 }}>
            {g.letters.map((ch, li) => {
              letterIdx += 1;
              const i = letterIdx;
              const isTyped = i < typed.length;
              const typedChar = typed[i];
              const correct =
                isTyped &&
                (typedChar?.toLowerCase() ?? "") === ch.toLowerCase();
              const isCurrent = i === typed.length && !done;

              const underlineColor = revealed
                ? "#534AB7"
                : isTyped
                ? correct
                  ? "#1D9E75"
                  : "#E24B4A"
                : "#2C2C2A";
              const charColor = revealed
                ? "#534AB7"
                : isTyped
                ? correct
                  ? "#0F6E56"
                  : "#A32D2D"
                : "#2C2C2A";
              const display = isTyped
                ? revealed
                  ? ch
                  : correct
                  ? ch
                  : (typedChar ?? "").toUpperCase()
                : "";

              return (
                <div
                  key={li}
                  className="flex flex-col items-center justify-between"
                  style={{ width: 28, height: 56, gap: 8 }}
                >
                  <div className="flex flex-1 items-center justify-center w-full">
                    {display ? (
                      <span
                        className="font-semibold leading-none"
                        style={{
                          color: charColor,
                          fontSize: revealed ? "28px" : "24px",
                          textShadow: revealed
                            ? "0 0 12px rgba(83,74,183,0.25)"
                            : "none",
                          animation: revealed
                            ? "revealPop .35s ease"
                            : undefined,
                        }}
                      >
                        {display}
                      </span>
                    ) : isCurrent ? (
                      <span
                        className="block w-[2px] h-6 rounded-sm"
                        style={{
                          backgroundColor: "#5F5E5A",
                          animation: "caretBlink 0.9s steps(1) infinite",
                        }}
                      />
                    ) : null}
                  </div>
                  <span
                    className="block rounded-full shrink-0"
                    style={{
                      width: revealed ? 28 : 26,
                      height: revealed ? 5 : 4,
                      backgroundColor: underlineColor,
                      transition: "background-color .15s, width .15s",
                    }}
                  />
                </div>
              );
            })}
            {g.suffix && (
              <div
                className="flex flex-col items-center justify-between"
                style={{ width: 20, height: 56, gap: 8 }}
              >
                <div className="flex flex-1 items-center justify-center w-full text-[22px] leading-none font-medium text-[#888780]">
                  {g.suffix}
                </div>
                <span
                  className="block rounded-full shrink-0"
                  style={{ width: 16, height: 4, backgroundColor: "#D3D1C7" }}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
