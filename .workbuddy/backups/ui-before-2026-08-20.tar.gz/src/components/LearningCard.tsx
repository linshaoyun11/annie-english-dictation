import { useEffect, useRef, useState } from "react";
import { type WordEntry, gradeLabel } from "../data/curriculum";
import { pointsForEntry } from "../lib/users";
import SoundWave from "./SoundWave";
import SpellingInput from "./SpellingInput";

interface LearningCardProps {
  entry: WordEntry;
  unitTitle: string;
  orderInUnit: number; // 从 1 开始
  unitSize: number;
  onComplete: (entryId: string) => void;
  onNext: () => void;
  onDontKnow: (entryId: string) => void;
  /** 词条拼错过或点过"我不会"（用于年级完成统计，整题只触发一次） */
  onMistake?: (entryId: string) => void;
  /** 冻结模式：单元完成祝贺页弹出时置 true，阻止自动跳题与自动朗读 */
  frozen?: boolean;
  replay: () => void;
  stopAudio: () => void;
  startAudio: (text: string) => void;
}

export default function LearningCard({
  entry,
  unitTitle,
  orderInUnit,
  unitSize,
  onComplete,
  onNext,
  onDontKnow,
  onMistake,
  frozen = false,
  replay,
  stopAudio,
  startAudio,
}: LearningCardProps) {
  const [showHint, setShowHint] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [revealReason, setRevealReason] = useState<"dontKnow" | "strike5" | null>(null);
  const [revealSignal, setRevealSignal] = useState(0);
  const autoNextTimer = useRef<number | null>(null);

  useEffect(() => {
    setShowHint(false);
    setCompleted(false);
    setRevealed(false);
    setRevealReason(null);
    // 庆祝页弹出期间不自动播放音频（避免祝贺页背后响着下一题的朗读）
    if (!frozen) startAudio(entry.english);
    return () => {
      stopAudio();
      if (autoNextTimer.current) {
        window.clearTimeout(autoNextTimer.current);
        autoNextTimer.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entry.id, frozen]);

  // 关键竞态修复：答对最后一题时 frozen 还是 false，autoNextTimer 已在排队；
  // 祝贺页弹出（frozen → true）后必须清除该 timer，否则 1.8s 后仍会切题播放下一题音频
  useEffect(() => {
    if (frozen && autoNextTimer.current) {
      window.clearTimeout(autoNextTimer.current);
      autoNextTimer.current = null;
    }
  }, [frozen]);

  // 空格键 = 切换查看提示
  // 拼写输入框是"隐藏透明 input"（自动聚焦、只收字母，空格字符本来就不参与拼写），
  // 因此焦点在它上面时按空格也应触发提示；仅避开可见按钮/真实输入框。
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== "Space") return;
      if (frozen) return; // 庆祝页打开时不响应空格
      if (e.isComposing || e.keyCode === 229) return; // 中文输入法选词时不误触
      const t = e.target as HTMLElement | null;
      if (t) {
        const tag = t.tagName;
        const isHiddenInput =
          tag === "INPUT" && getComputedStyle(t).opacity === "0";
        if (
          tag === "BUTTON" ||
          tag === "TEXTAREA" ||
          t.isContentEditable ||
          (tag === "INPUT" && !isHiddenInput)
        ) {
          return;
        }
      }
      if (completed || revealed) return;
      e.preventDefault();
      setShowHint((v) => !v);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [completed, revealed, frozen]);

  const handleComplete = () => {
    setCompleted(true);
    stopAudio();
    onComplete(entry.id);
    // 答对后停留片刻展示答案，然后自动进入下一题（庆祝页弹出期间不自动跳题）
    if (frozen) return;
    autoNextTimer.current = window.setTimeout(() => {
      autoNextTimer.current = null;
      onNext();
    }, 1800);
  };

  /** 统一揭示流程："我不会"或拼错满 5 次 → 填充答案、加重点记忆 */
  const revealAnswer = (reason: "dontKnow" | "strike5") => {
    if (completed || revealed) return;
    setRevealReason(reason);
    setRevealed(true);
    setRevealSignal((s) => s + 1);
    stopAudio();
    onDontKnow(entry.id);
    onMistake?.(entry.id); // "不会"也计入拼错/不会统计
    // 不自动跳转，等用户点击"记住了，进入下一题"
  };

  return (
    <div className="flex h-full flex-col items-center px-5 pt-6 pb-24">
      {/* 顶部信息（右侧留出退出按钮的空间） */}
      <div className="flex w-full items-center justify-between pr-10">
        <span className="text-xs text-[#888780]">
          {gradeLabel(entry.grade)} · {unitTitle}
        </span>
        <span className="text-xs tabular-nums text-[#888780]">
          {orderInUnit} / {unitSize}
        </span>
      </div>
      <div className="mt-2 h-[3px] w-full rounded-full bg-[#EAE8E0]">
        <div
          className="h-[3px] rounded-full bg-[#1D9E75] transition-all duration-300"
          style={{ width: `${(orderInUnit / unitSize) * 100}%` }}
        />
      </div>

      {/* 中央视觉焦点：发音波浪 / 答对徽章 / 记忆徽章 */}
      <div className="mt-12 flex flex-col items-center">
        {completed ? (
          <div className="relative flex h-24 w-24 items-center justify-center">
            <span className="absolute h-24 w-24 rounded-full border-2 border-[#1D9E75] animate-[ringOut_.9s_ease-out_forwards]" />
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-[#E1F5EE] animate-[badgePop_.45s_cubic-bezier(.34,1.56,.64,1)]">
              <svg
                width="34"
                height="34"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#0F6E56"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
                style={{ strokeDasharray: 26, animation: "checkDraw .35s ease .15s both" }}
              >
                <path d="M20 6L9 17l-5-5" />
              </svg>
            </span>
          </div>
        ) : revealed ? (
          <div className="flex h-24 w-24 items-center justify-center">
            <span className="flex h-20 w-20 items-center justify-center rounded-full bg-[#FAEEDA] animate-[badgePop_.45s_ease]">
              <svg
                width="30"
                height="30"
                viewBox="0 0 24 24"
                fill="none"
                stroke="#854F0B"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
              </svg>
            </span>
          </div>
        ) : (
          <SoundWave active={!completed && !revealed} onClick={replay} />
        )}
        <p className="mt-3 text-xs text-[#888780]">
          {completed
            ? "回答正确"
            : revealed
            ? revealReason === "strike5"
              ? "多练几遍，马上就记住啦"
              : "没关系，看一遍答案"
            : "听发音，拼写你听到的内容"}
        </p>
        {completed && (
          <span className="mt-2 rounded-full bg-[#E1F5EE] px-3 py-1 text-xs font-medium text-[#0F6E56] animate-[fadeIn_.3s_ease_.25s_both]">
            +{pointsForEntry(entry.type)} 积分
          </span>
        )}
      </div>

      {/* 查看提示按钮 */}
      {!completed && !revealed && (
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => setShowHint((v) => !v)}
          className="mt-7 rounded-full border border-[#D3D1C7] px-5 py-1.5 text-xs text-[#5F5E5A] transition-colors active:bg-[#F1EFE8]"
        >
          {showHint ? "隐藏提示" : "查看提示"}
        </button>
      )}

      {/* 提示 / 释义卡片 */}
      <div className="mt-4 flex min-h-[76px] flex-col items-center justify-start">
        {showHint && !completed && !revealed && (
          <div className="flex flex-col items-center gap-1 animate-[fadeIn_.3s_ease]">
            {entry.phonetic && (
              <span className="text-sm text-[#534AB7]">{entry.phonetic}</span>
            )}
            <span className="text-sm text-[#444441]">{entry.chinese}</span>
          </div>
        )}
        {completed && (
          <div className="w-full max-w-[300px] rounded-2xl bg-white px-5 py-4 text-center shadow-[0_2px_12px_rgba(44,44,42,0.07)] animate-[slideUp_.35s_ease]">
            {entry.phonetic && (
              <p className="text-sm text-[#534AB7]">{entry.phonetic}</p>
            )}
            <p className="mt-1 text-base font-medium text-[#444441]">
              {entry.chinese}
            </p>
          </div>
        )}
        {revealed && (
          <div className="w-full max-w-[300px] rounded-2xl border border-[#EF9F27]/35 bg-[#FFFCF5] px-5 py-4 text-center animate-[slideUp_.35s_ease]">
            {entry.phonetic && (
              <p className="text-sm text-[#854F0B]">{entry.phonetic}</p>
            )}
            <p className="mt-1 text-base font-medium text-[#444441]">
              {entry.chinese}
            </p>
          </div>
        )}
      </div>

      {/* 拼写输入 */}
      <div className="mt-7 w-full">
        <SpellingInput
          target={entry.english}
          resetKey={entry.id}
          onComplete={handleComplete}
          onFirstMistake={() => onMistake?.(entry.id)}
          revealSignal={revealSignal}
          onStrike5={() => revealAnswer("strike5")}
        />
      </div>

      {/* "我不会" / "记住了，进入下一题" 按钮 */}
      {!completed && (
        revealed ? (
          <div className="mt-6 flex flex-col items-center gap-2">
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              onClick={onNext}
              className="rounded-full bg-[#534AB7] px-6 py-2 text-sm font-medium text-white transition-transform active:scale-[0.97]"
            >
              记住了，进入下一题
            </button>
            <p className="text-xs text-[#888780] animate-[fadeIn_.4s_ease]">
              {revealReason === "strike5"
                ? "拼错 5 次 · 本词条已自动加入重点记忆列表"
                : "本词条已自动加入重点记忆列表"}
            </p>
          </div>
        ) : (
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => revealAnswer("dontKnow")}
            className="mt-6 rounded-full border border-[#D3D1C7] px-5 py-1.5 text-xs text-[#5F5E5A] transition-colors active:bg-[#F1EFE8]"
          >
            我不会
          </button>
        )
      )}

      {/* 完成后：自动进入下一题（进度条与 1.8s 定时同步，点击跳过） */}
      {completed && (
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={onNext}
          className="mt-8 flex flex-col items-center gap-2.5 animate-[slideUp_.4s_ease]"
        >
          <span className="block h-1 w-28 overflow-hidden rounded-full bg-[#EAE8E0]">
            <span
              className="block h-full rounded-full bg-[#1D9E75]"
              style={{ animation: "autoNextBar 1.8s linear forwards" }}
            />
          </span>
          <span className="text-xs text-[#888780]">正在进入下一题 · 点击跳过</span>
        </button>
      )}
    </div>
  );
}
