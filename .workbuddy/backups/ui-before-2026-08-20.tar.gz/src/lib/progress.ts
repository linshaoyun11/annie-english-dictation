import {
  CURRICULUM_VERSION,
  getAllEntries,
  getCurriculum,
  type CurriculumVersion,
} from "../data/curriculum";

// 进度按「用户 + 教材版本」隔离存储：eng-learning-progress-v3:{version}:{userId}
// v2（旧版，仅按用户）数据会在人教版本下自动迁移，其他版本为新进度
const STORAGE_PREFIX = "eng-learning-progress-v3";
const LEGACY_PREFIX = "eng-learning-progress-v2";

function storageKey(userId: string, version: CurriculumVersion) {
  return `${STORAGE_PREFIX}:${version}:${userId}`;
}

export interface Progress {
  curriculumVersion: number; // 词库版本，不匹配时进度重置
  version: CurriculumVersion; // 教材版本
  unitIndex: number;
  entryIndex: number;
  unitOrder: string[]; // 当前单元的随机题目顺序（entry id 列表）
  completedEntryIds: string[];
  difficultEntryIds: string[]; // "我不会"的条目
  errorCounts: Record<string, number>;
  lastLearnedAt: number;
  /** 各单元首次开始学习的时间戳（key: `${grade}-${unit}`） */
  unitStartedAt?: Record<string, number>;
  /** 曾经拼错或点过"我不会"的词条 id（去重） */
  mistakeEntryIds?: string[];
  /** 已弹出过完成祝贺页的单元（key: `${grade}-${unit}`） */
  celebratedUnits?: string[];
}

export function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function makeUnitOrder(
  unitIndex: number,
  version: CurriculumVersion
): string[] {
  const unit = getCurriculum(version)[unitIndex];
  return shuffle(unit.entries.map((e) => e.id));
}

/** 旧版（v2）人教进度 → 迁移到新格式，避免升级后老用户进度丢失 */
function migrateLegacy(userId: string): Progress | null {
  try {
    const raw = localStorage.getItem(`${LEGACY_PREFIX}:${userId}`);
    if (!raw) return null;
    const p = JSON.parse(raw);
    if (
      typeof p.unitIndex === "number" &&
      p.unitIndex >= 0 &&
      p.unitIndex < getCurriculum("renjiao").length &&
      p.curriculumVersion === CURRICULUM_VERSION &&
      Array.isArray(p.completedEntryIds)
    ) {
      const migrated: Progress = {
        ...p,
        version: "renjiao",
        difficultEntryIds: Array.isArray(p.difficultEntryIds)
          ? p.difficultEntryIds
          : [],
        errorCounts: p.errorCounts ?? {},
      };
      saveProgress(userId, migrated);
      return migrated;
    }
  } catch {
    /* ignore */
  }
  return null;
}

export function loadProgress(
  userId: string,
  version: CurriculumVersion
): Progress {
  try {
    const raw = localStorage.getItem(storageKey(userId, version));
    if (raw) {
      const p = JSON.parse(raw) as Progress;
      if (
        typeof p.unitIndex === "number" &&
        p.unitIndex >= 0 &&
        p.unitIndex < getCurriculum(version).length &&
        p.version === version &&
        // 词库版本不匹配时进度作废（条目 ID 已变），返回全新进度
        p.curriculumVersion === CURRICULUM_VERSION
      ) {
        // 兼容旧数据：补全 difficultEntryIds / 单元统计字段
        if (!Array.isArray(p.difficultEntryIds)) p.difficultEntryIds = [];
        if (!p.errorCounts || typeof p.errorCounts !== "object")
          p.errorCounts = {};
        if (!Array.isArray(p.mistakeEntryIds)) p.mistakeEntryIds = [];
        // 旧字段（年级粒度）迁移到新字段（单元粒度）：
        // 已庆祝过的年级 → 该年级下所有单元视为已庆祝；年级开始时间 → 复制到该年级各单元
        const legacyCelebrated = (p as unknown as { celebratedGrades?: number[] })
          .celebratedGrades;
        const legacyStarted = (p as unknown as {
          gradeStartedAt?: Record<string, number>;
        }).gradeStartedAt;
        if (!Array.isArray(p.celebratedUnits)) {
          p.celebratedUnits = [];
          if (Array.isArray(legacyCelebrated)) {
            const grades = new Set(legacyCelebrated);
            for (const u of getCurriculum(version)) {
              if (grades.has(u.grade)) p.celebratedUnits.push(`${u.grade}-${u.unit}`);
            }
          }
        }
        if (!p.unitStartedAt || typeof p.unitStartedAt !== "object") {
          p.unitStartedAt = {};
          if (legacyStarted && typeof legacyStarted === "object") {
            for (const u of getCurriculum(version)) {
              const t = legacyStarted[String(u.grade)];
              if (typeof t === "number") p.unitStartedAt[`${u.grade}-${u.unit}`] = t;
            }
          }
        }
        return p;
      }
    }
  } catch {
    /* ignore corrupted data */
  }
  // 人教版本：尝试迁移 v2 旧进度
  if (version === "renjiao") {
    const legacy = migrateLegacy(userId);
    if (legacy) return legacy;
  }
  return freshProgress(version);
}

export function freshProgress(version: CurriculumVersion): Progress {
  return {
    curriculumVersion: CURRICULUM_VERSION,
    version,
    unitIndex: 0,
    entryIndex: 0,
    unitOrder: makeUnitOrder(0, version),
    completedEntryIds: [],
    difficultEntryIds: [],
    errorCounts: {},
    lastLearnedAt: Date.now(),
    unitStartedAt: {},
    mistakeEntryIds: [],
    celebratedUnits: [],
  };
}

export function saveProgress(userId: string, p: Progress) {
  p.lastLearnedAt = Date.now();
  localStorage.setItem(storageKey(userId, p.version), JSON.stringify(p));
}

export function resetProgress(userId: string, version: CurriculumVersion) {
  localStorage.removeItem(storageKey(userId, version));
  // 旧版 v2 数据一并清除，避免重复迁移
  localStorage.removeItem(`${LEGACY_PREFIX}:${userId}`);
}

export function totalEntryCount(version: CurriculumVersion): number {
  return getAllEntries(version).length;
}

export function unitStats(p: Progress) {
  const total = totalEntryCount(p.version);
  const done = p.completedEntryIds.length;
  return { total, done, percent: Math.round((done / total) * 100) };
}
