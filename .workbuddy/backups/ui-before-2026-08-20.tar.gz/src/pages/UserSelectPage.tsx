import { useState } from "react";
import { avatarById, type User } from "../lib/users";
import PasswordModal from "../components/PasswordModal";
import Logo from "../components/Logo";

interface UserSelectPageProps {
  users: User[];
  onLogin: (user: User) => void;
  onRegister: () => void;
  onLeaderboard: () => void;
}

export default function UserSelectPage({
  users,
  onLogin,
  onRegister,
  onLeaderboard,
}: UserSelectPageProps) {
  const [pendingUser, setPendingUser] = useState<User | null>(null);

  const sorted = [...users].sort((a, b) => b.points - a.points);

  return (
    <div className="flex h-full flex-col px-6 pb-8">
      {/* 排行榜：保持右上角原位 */}
      <div className="flex items-center justify-end pt-6">
        <button
          type="button"
          onClick={onLeaderboard}
          className="flex items-center gap-1 rounded-full border border-[#E5E4E0] bg-white px-3 py-1.5 text-xs text-[#5F5E5A] transition-transform active:scale-[0.97]"
        >
          🏆 排行榜
        </button>
      </div>

      {/* LOGO + 应用名 */}
      <div className="mt-4 flex justify-center">
        <Logo size={88} />
      </div>
      <p className="mt-5 mb-6 text-center text-sm text-[#888780]">
        点击你的头像开始学习
      </p>

      {/* 用户头像网格 */}
      <div className="flex-1 overflow-y-auto">
        {users.length === 0 ? (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <div className="flex gap-2 text-4xl opacity-60">
              <span>🐶</span>
              <span>🐱</span>
              <span>🐼</span>
            </div>
            <p className="mt-4 text-sm text-[#888780]">
              还没有小伙伴
              <br />
              点击下方按钮注册第一个用户吧
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-3 gap-x-3 gap-y-6">
            {sorted.map((u) => {
              const avatar = avatarById(u.avatarId);
              return (
                <button
                  key={u.id}
                  type="button"
                  onClick={() => setPendingUser(u)}
                  className="flex flex-col items-center transition-transform active:scale-[0.95]"
                >
                  <div
                    className="flex h-[72px] w-[72px] items-center justify-center rounded-full text-[38px] shadow-sm border border-black/5"
                    style={{ backgroundColor: avatar.color }}
                  >
                    {avatar.emoji}
                  </div>
                  <span className="mt-2 text-sm font-medium">{avatar.name}</span>
                  <span className="mt-0.5 text-[11px] text-[#B4A44A]">
                    ⭐ {u.points} 分
                  </span>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 注册按钮 */}
      <button
        type="button"
        onClick={onRegister}
        className="mt-6 w-full rounded-xl bg-[#534AB7] py-3 text-[15px] font-medium text-white transition-transform active:scale-[0.98]"
      >
        ＋ 新用户注册
      </button>

      {pendingUser && (
        <PasswordModal
          user={pendingUser}
          onSuccess={() => onLogin(pendingUser)}
          onClose={() => setPendingUser(null)}
        />
      )}
    </div>
  );
}
