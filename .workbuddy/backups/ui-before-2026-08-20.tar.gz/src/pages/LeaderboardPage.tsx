import { avatarById, type User } from "../lib/users";

interface LeaderboardPageProps {
  users: User[];
  currentUserId: string | null;
  onBack: () => void;
}

const MEDALS = ["🥇", "🥈", "🥉"];

export default function LeaderboardPage({ users, currentUserId, onBack }: LeaderboardPageProps) {
  const sorted = [...users].sort(
    (a, b) => b.points - a.points || b.learnedCount - a.learnedCount
  );

  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-8">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full text-[#888780] active:bg-[#F1EFE8]"
          aria-label="返回"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
        <h1 className="text-lg font-medium">🏆 积分排行榜</h1>
      </div>
      <p className="mt-1 ml-11 text-xs text-[#888780]">
        单词 +5 · 短语 +8 · 句子 +10
      </p>

      <div className="mt-5 flex-1 overflow-y-auto">
        {sorted.length === 0 ? (
          <p className="mt-16 text-center text-sm text-[#888780]">
            还没有用户注册，快去注册吧
          </p>
        ) : (
          <div className="space-y-2.5">
            {sorted.map((u, i) => {
              const avatar = avatarById(u.avatarId);
              const isMe = u.id === currentUserId;
              return (
                <div
                  key={u.id}
                  className={`flex items-center gap-3 rounded-2xl border p-3.5 ${
                    isMe
                      ? "border-[#534AB7] bg-[#F4F2FF]"
                      : "border-[#E5E4E0] bg-white"
                  }`}
                >
                  <span className="w-7 text-center text-base font-semibold text-[#888780]">
                    {i < 3 ? MEDALS[i] : i + 1}
                  </span>
                  <div
                    className="flex h-11 w-11 items-center justify-center rounded-full text-2xl"
                    style={{ backgroundColor: avatar.color }}
                  >
                    {avatar.emoji}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {avatar.name}
                      {isMe && (
                        <span className="ml-1.5 rounded-full bg-[#534AB7] px-1.5 py-0.5 text-[10px] text-white">
                          我
                        </span>
                      )}
                    </p>
                    <p className="mt-0.5 text-[11px] text-[#888780]">
                      已学 {u.learnedCount} 个条目
                    </p>
                  </div>
                  <span className="text-base font-semibold text-[#B4A44A]">
                    {u.points}
                    <span className="ml-0.5 text-[11px] font-normal text-[#888780]">
                      分
                    </span>
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
