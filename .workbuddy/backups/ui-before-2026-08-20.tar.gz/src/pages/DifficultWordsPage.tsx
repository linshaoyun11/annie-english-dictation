import { useMemo, useState, useRef } from "react";
import {
  getCurriculum,
  gradeLabel,
  getAllEntries,
  type CurriculumVersion,
} from "../data/curriculum";
import type { Progress } from "../lib/progress";
import { resolveAudio } from "../lib/audio";
import type { Accent } from "../lib/users";

interface DifficultWordsPageProps {
  progress: Progress;
  version: CurriculumVersion;
  accent: Accent;
  onBack: () => void;
  onRemove: (entryId: string) => void;
  onStartLearning: () => void;
}

export default function DifficultWordsPage({
  progress,
  version,
  accent,
  onBack,
  onRemove,
  onStartLearning,
}: DifficultWordsPageProps) {
  const [playingId, setPlayingId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const cur = getCurriculum(version);

  const difficultEntries = useMemo(() => {
    const allMap = new Map(getAllEntries(version).map((e) => [e.id, e]));
    return progress.difficultEntryIds
      .map((id) => allMap.get(id))
      .filter((e): e is NonNullable<typeof e> => !!e);
  }, [progress.difficultEntryIds, version]);

  const playAudio = async (english: string, entryId: string) => {
    // 停掉上一个
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    setPlayingId(entryId);

    const result = await resolveAudio(english, accent);
    const fallbackSpeak = () => {
      // 兜底 Web Speech（按口音选择语言）
      const u = new SpeechSynthesisUtterance(english);
      u.lang = accent === "uk" ? "en-GB" : "en-US";
      u.rate = 0.9;
      u.onend = () => setPlayingId(null);
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    };
    if (result) {
      const audio = new Audio(result.url);
      audio.playbackRate = 0.9;
      audio.onended = () => setPlayingId(null);
      audio.onerror = fallbackSpeak;
      audioRef.current = audio;
      audio.play().catch(fallbackSpeak);
    } else {
      fallbackSpeak();
    }
  };

  return (
    <div className="h-full overflow-y-auto px-5 pb-10">
      {/* 顶部导航 */}
      <div className="flex items-center gap-3 pt-8">
        <button
          type="button"
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full text-[#888780] transition-colors active:bg-[#F1EFE8]"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5" />
            <path d="M12 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-lg font-medium">重点记忆</h1>
        <span className="text-xs text-[#888780]">
          {difficultEntries.length} 个
        </span>
      </div>

      {difficultEntries.length === 0 ? (
        <div className="mt-24 flex flex-col items-center gap-4 text-center">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-[#F1EFE8]">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#888780" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 11l3 3L22 4" />
              <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" />
            </svg>
          </div>
          <p className="text-sm text-[#888780]">
            还没有需要重点记忆的内容
            <br />
            学习时点击「我不会」即可添加
          </p>
        </div>
      ) : (
        <div className="mt-5 flex flex-col gap-3">
          <button
            type="button"
            onClick={onStartLearning}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-[#534AB7] py-3.5 text-sm font-medium text-white shadow-sm transition-transform active:scale-[0.98]"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M11 5L6 9H2v6h4l5 4V5z" />
              <path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" />
            </svg>
            开始学习重点记忆
            <span className="ml-1 rounded-full bg-white/20 px-2 py-0.5 text-[11px]">
              {difficultEntries.length} 词
            </span>
          </button>
          {difficultEntries.map((entry) => {
            const unit = cur.find(
              (u) => u.grade === entry.grade && u.unit === entry.unit
            );
            return (
              <div
                key={entry.id}
                className="rounded-xl border border-[#E5E4E0] bg-white p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-baseline gap-2">
                      <span className="text-base font-medium text-[#2C2C2A]">
                        {entry.english}
                      </span>
                      {entry.phonetic && (
                        <span className="text-xs text-[#534AB7]">
                          {entry.phonetic}
                        </span>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-[#444441]">
                      {entry.chinese}
                    </p>
                    <p className="mt-1 text-[11px] text-[#B4B2A9]">
                      {gradeLabel(entry.grade)}
                      {unit ? ` · ${unit.title}` : ""} ·{" "}
                      {entry.type === "word"
                        ? "单词"
                        : entry.type === "phrase"
                        ? "短语"
                        : "句子"}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <button
                      type="button"
                      onClick={() => playAudio(entry.english, entry.id)}
                      className="flex h-8 w-14 items-center justify-center rounded-full border border-[#E5E4E0] transition-colors active:bg-[#F1EFE8]"
                    >
                      {playingId === entry.id ? (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#534AB7" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <rect x="6" y="4" width="4" height="16" rx="1" />
                          <rect x="14" y="4" width="4" height="16" rx="1" />
                        </svg>
                      ) : (
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5F5E5A" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M11 5L6 9H2v6h4l5 4V5z" />
                          <path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07" />
                        </svg>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => onRemove(entry.id)}
                      className="flex h-8 w-14 items-center justify-center rounded-full border border-[#E8C5C4] text-xs font-medium text-[#C0454A] transition-colors active:bg-[#FDF2F2]"
                    >
                      删除
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
