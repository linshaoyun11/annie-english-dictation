import { useState } from "react";
import {
  CURRICULUM_LABELS,
  getCurriculum,
  gradeLabel,
  type CurriculumVersion,
} from "../data/curriculum";
import { type Progress, unitStats } from "../lib/progress";
import { primeSpeech } from "../hooks/useSpeechLoop";
import { avatarById, type User } from "../lib/users";
import Logo from "../components/Logo";

interface HomePageProps {
  user: User;
  progress: Progress;
  version: CurriculumVersion;
  onStart: (unitIndex?: number) => void;
  onReset: () => void;
  onLogout: () => void;
  onLeaderboard: () => void;
  onDifficultWords: () => void;
  onSettings: () => void;
}

export default function HomePage({
  user,
  progress,
  version,
  onStart,
  onReset,
  onLogout,
  onLeaderboard,
  onDifficultWords,
  onSettings,
}: HomePageProps) {
  const stats = unitStats(progress);
  const cur = getCurriculum(version);
  const currentUnit = cur[progress.unitIndex];
  const avatar = avatarById(user.avatarId);
  const doneInCurrent = currentUnit.entries.filter((e) =>
    progress.completedEntryIds.includes(e.id)
  ).length;

  const grades = Array.from(new Set(cur.map((u) => u.grade)));
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  return (
    <div className="h-full overflow-y-auto px-5 pb-10">
      {/* 用户信息栏 */}
      <div className="flex items-center justify-between pt-8">
        <div className="flex items-center gap-3">
          <div
            className="flex h-12 w-12 items-center justify-center rounded-full text-2xl shadow-sm border border-black/5"
            style={{ backgroundColor: avatar.color }}
          >
            {avatar.emoji}
          </div>
          <div>
            <p className="text-sm font-medium">{avatar.name}</p>
            <p className="text-xs text-[#B4A44A]">⭐ {user.points} 积分</p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onDifficultWords}
            className="relative rounded-full border border-[#E5E4E0] bg-white px-3 py-1.5 text-xs text-[#5F5E5A] transition-transform active:scale-[0.97]"
          >
            📝 重点记忆
            {progress.difficultEntryIds.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#E24B4A] px-1 text-[10px] font-medium text-white">
                {progress.difficultEntryIds.length}
              </span>
            )}
          </button>
          <button
            type="button"
            onClick={onLeaderboard}
            className="rounded-full border border-[#E5E4E0] bg-white px-3 py-1.5 text-xs text-[#5F5E5A] transition-transform active:scale-[0.97]"
          >
            🏆 排行榜
          </button>
          <button
            type="button"
            onClick={onLogout}
            className="rounded-full border border-[#E5E4E0] bg-white px-3 py-1.5 text-xs text-[#5F5E5A] transition-transform active:scale-[0.97]"
          >
            切换
          </button>
        </div>
      </div>

      <div className="pt-6 pb-6 flex flex-col items-center">
        <Logo size={56} withText={false} />
        <h1 className="mt-3 text-xl font-semibold tracking-wide">安妮英语听写</h1>
        <p className="mt-1.5 text-sm text-[#888780]">
          小学一年级 · 初中三年级 · {CURRICULUM_LABELS[version]}进度
        </p>
      </div>

      {/* 进度卡片 */}
      <div className="rounded-2xl bg-white border border-[#E5E4E0] p-5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-[#888780]">当前进度</p>
            <p className="mt-1 text-base font-medium">
              {gradeLabel(currentUnit.grade)} · {currentUnit.title}
            </p>
            <p className="mt-0.5 text-xs text-[#888780]">
              本单元 {doneInCurrent}/{currentUnit.entries.length} · 总进度{" "}
              {stats.done}/{stats.total}（{stats.percent}%）
            </p>
          </div>
          <button
            type="button"
            onClick={onSettings}
            title="点击选择教材和读音"
            aria-label="设置"
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#E5E4E0] bg-white text-[#5F5E5A] transition-transform active:scale-[0.94]"
          >
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="3" />
              <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
            </svg>
          </button>
        </div>
        <div className="mt-3 h-[5px] w-full rounded-full bg-[#F1EFE8]">
          <div
            className="h-[5px] rounded-full bg-[#1D9E75]"
            style={{ width: `${Math.max(stats.percent, 2)}%` }}
          />
        </div>
        <button
          type="button"
          onClick={() => {
            primeSpeech();
            onStart();
          }}
          className="mt-5 w-full rounded-xl bg-[#534AB7] py-3 text-[15px] font-medium text-white transition-transform active:scale-[0.98]"
        >
          {stats.done > 0 ? "继续学习" : "开始学习"}
        </button>
      </div>

      {/* 年级选择 */}
      <h2 className="mt-7 mb-3 text-sm font-medium text-[#444441]">
        按年级开始
      </h2>
      <div className="grid grid-cols-2 gap-2.5">
        {grades.map((g) => {
          const unitsOfGrade = cur.filter((u) => u.grade === g);
          const doneCount = unitsOfGrade.reduce(
            (s, u) =>
              s +
              u.entries.filter((e) =>
                progress.completedEntryIds.includes(e.id)
              ).length,
            0
          );
          const totalCount = unitsOfGrade.reduce(
            (s, u) => s + u.entries.length,
            0
          );
          return (
            <button
              key={g}
              type="button"
              onClick={() => {
                primeSpeech();
                onStart(cur.indexOf(unitsOfGrade[0]));
              }}
              className="flex flex-col items-start rounded-xl border border-[#E5E4E0] bg-white p-3.5 text-left transition-transform active:scale-[0.98]"
            >
              <span className="text-sm font-medium">{gradeLabel(g)}</span>
              <span className="mt-1 text-[11px] text-[#888780]">
                {unitsOfGrade.length} 个单元 · {doneCount}/{totalCount} 已完成
              </span>
            </button>
          );
        })}
      </div>

      <button
        type="button"
        onClick={() => setShowResetConfirm(true)}
        className="mt-8 w-full rounded-xl border border-[#D3D1C7] py-2.5 text-sm text-[#888780]"
      >
        清空学习进度
      </button>

      {/* 清空进度确认弹窗（重点提示积分一并清零） */}
      {showResetConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-8"
          onClick={() => setShowResetConfirm(false)}
        >
          <div
            className="w-full max-w-xs animate-[fadeIn_.2s_ease] rounded-2xl bg-white p-6 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#FDECEB] text-lg">
                ⚠️
              </span>
              <h2 className="text-base font-medium text-[#2C2C2A]">
                清空学习进度？
              </h2>
            </div>
            <div className="mt-4 rounded-xl bg-[#FDECEB] px-4 py-3">
              <p className="text-sm font-semibold text-[#C0392B]">
                注意：全部积分（⭐ {user.points} 分）将一并清零！
              </p>
              <p className="mt-1 text-xs leading-5 text-[#A32D2D]">
                当前教材的学习进度、积分与已学数量都会被删除，此操作不可恢复。
              </p>
            </div>
            <div className="mt-5 flex gap-3">
              <button
                type="button"
                onClick={() => setShowResetConfirm(false)}
                className="flex-1 rounded-full border border-[#D3D1C7] py-2.5 text-sm text-[#5F5E5A] transition-colors active:bg-[#F1EFE8]"
              >
                取消
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowResetConfirm(false);
                  onReset();
                }}
                className="flex-1 rounded-full bg-[#E24B4A] py-2.5 text-sm font-medium text-white transition-transform active:scale-[0.97]"
              >
                确认清空
              </button>
            </div>
          </div>
        </div>
      )}

      <p className="mt-4 text-center text-[11px] leading-5 text-[#B4B2A9]">
        提示：请打开设备声音，学习时将循环朗读
        <br />
        点击波浪图标可立即重听
      </p>
    </div>
  );
}
