import { useMemo, useState } from "react";
import { AVATARS, takenAvatarIds, type User } from "../lib/users";

interface RegisterPageProps {
  users: User[];
  onRegister: (avatarId: string, password: string) => { ok: boolean; error?: string };
  onBack: () => void;
}

export default function RegisterPage({ users, onRegister, onBack }: RegisterPageProps) {
  const taken = useMemo(() => takenAvatarIds(users), [users]);
  const available = AVATARS.filter((a) => !taken.has(a.id)).length;

  const [selected, setSelected] = useState<string | null>(null);
  const [pwd, setPwd] = useState("");
  const [pwd2, setPwd2] = useState("");
  const [error, setError] = useState<string | null>(null);

  const pwdClean = pwd.replace(/\D/g, "").slice(0, 4);
  const pwd2Clean = pwd2.replace(/\D/g, "").slice(0, 4);

  const canSubmit =
    !!selected && /^\d{4}$/.test(pwdClean) && pwdClean === pwd2Clean;

  const handleSubmit = () => {
    if (!selected) {
      setError("请先选一个喜欢的头像");
      return;
    }
    const result = onRegister(selected, pwdClean);
    if (!result.ok) {
      setError(result.error ?? "注册失败");
    }
  };

  return (
    <div className="flex h-full flex-col px-6 pb-8 pt-8">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full text-[#888780] active:bg-[#F1EFE8]"
          aria-label="返回"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M15 18l-6-6 6-6" />
          </svg>
        </button>
        <h1 className="text-lg font-medium">新用户注册</h1>
      </div>
      <p className="mt-1 ml-11 text-xs text-[#888780]">
        选一个喜欢的头像，再设置 4 位数字密码
        {available < AVATARS.length && `（还剩 ${available} 个可选）`}
      </p>

      {/* 头像选择 */}
      <div className="mt-5 flex-1 overflow-y-auto">
        <div className="grid grid-cols-4 gap-x-2 gap-y-4">
          {AVATARS.map((a) => {
            const isTaken = taken.has(a.id);
            const isSelected = selected === a.id;
            return (
              <button
                key={a.id}
                type="button"
                disabled={isTaken}
                onClick={() => {
                  setSelected(a.id);
                  setError(null);
                }}
                className={`relative flex flex-col items-center rounded-2xl p-2 transition-all ${
                  isTaken
                    ? "cursor-not-allowed opacity-40 grayscale"
                    : "active:scale-[0.93]"
                } ${
                  isSelected
                    ? "bg-[#EDEBFF] ring-2 ring-[#534AB7]"
                    : "bg-transparent"
                }`}
              >
                <div
                  className="flex h-14 w-14 items-center justify-center rounded-full text-[30px] shadow-sm border border-black/5"
                  style={{ backgroundColor: a.color }}
                >
                  {a.emoji}
                </div>
                <span className="mt-1.5 text-[11px] text-[#5F5E5A]">{a.name}</span>
                {isTaken && (
                  <span className="absolute right-1 top-1 text-xs">🔒</span>
                )}
                {isSelected && !isTaken && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-[#534AB7] text-[10px] text-white">
                    ✓
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 密码设置 */}
      <div className="mt-5 space-y-3">
        <div>
          <label className="mb-1 block text-xs text-[#888780]">密码（4 位数字）</label>
          <input
            value={pwdClean}
            onChange={(e) => {
              setPwd(e.target.value);
              setError(null);
            }}
            inputMode="numeric"
            maxLength={4}
            placeholder="••••"
            className="w-full rounded-xl border border-[#E5E4E0] bg-white px-4 py-3 text-center text-lg tracking-[0.8em]"
          />
        </div>
        <div>
          <label className="mb-1 block text-xs text-[#888780]">再输入一次</label>
          <input
            value={pwd2Clean}
            onChange={(e) => {
              setPwd2(e.target.value);
              setError(null);
            }}
            inputMode="numeric"
            maxLength={4}
            placeholder="••••"
            className={`w-full rounded-xl border bg-white px-4 py-3 text-center text-lg tracking-[0.8em] ${
              pwd2Clean.length === 4 && pwd2Clean !== pwdClean
                ? "border-[#E25C4A]"
                : "border-[#E5E4E0]"
            }`}
          />
        </div>
        {pwd2Clean.length === 4 && pwd2Clean !== pwdClean && (
          <p className="text-xs text-[#E25C4A]">两次输入的密码不一致</p>
        )}
        {error && <p className="text-xs text-[#E25C4A]">{error}</p>}
      </div>

      <button
        type="button"
        disabled={!canSubmit}
        onClick={handleSubmit}
        className={`mt-5 w-full rounded-xl py-3 text-[15px] font-medium transition-transform ${
          canSubmit
            ? "bg-[#534AB7] text-white active:scale-[0.98]"
            : "bg-[#E5E4E0] text-[#B4B2A9]"
        }`}
      >
        注册并开始学习
      </button>
    </div>
  );
}
