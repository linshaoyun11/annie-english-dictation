import { useMemo, useState } from "react";
import {
  CURRICULUM_LABELS,
  getAllEntries,
  getCurriculum,
  type CurriculumVersion,
} from "../data/curriculum";
import { avatarById, type Accent, type User, type UserConfig } from "../lib/users";

interface SettingsPageProps {
  user: User;
  onBack: () => void;
  onSave: (config: UserConfig) => void;
}

/** 教材版本简介（年级结构说明） */
const CURRICULUM_DESC: Record<CurriculumVersion, string> = {
  renjiao: "人教版 · 1-6 年级起点 + 初中新目标",
  waiyanshe: "外研社 · 一年级/三年级起点 + 初中新标准",
  oxford: "沪教牛津 · 1-6 年级起始 + 初中牛津上海版",
};

const VERSIONS: CurriculumVersion[] = ["renjiao", "waiyanshe", "oxford"];

const ACCENTS: { id: Accent; label: string; desc: string }[] = [
  { id: "us", label: "美式发音", desc: "美音 (American English)" },
  { id: "uk", label: "英式发音", desc: "英音 (British English)" },
];

export default function SettingsPage({
  user,
  onBack,
  onSave,
}: SettingsPageProps) {
  const avatar = avatarById(user.avatarId);
  const [curriculum, setCurriculum] = useState<CurriculumVersion>(
    user.config.curriculum
  );
  const [accent, setAccent] = useState<Accent>(user.config.accent);
  const [saved, setSaved] = useState(false);

  // 各版本统计（单元数 / 条目数）
  const stats = useMemo(() => {
    return Object.fromEntries(
      VERSIONS.map((v) => [
        v,
        { units: getCurriculum(v).length, entries: getAllEntries(v).length },
      ])
    ) as Record<CurriculumVersion, { units: number; entries: number }>;
  }, []);

  const commit = (next: { curriculum?: CurriculumVersion; accent?: Accent }) => {
    const config = {
      curriculum: next.curriculum ?? curriculum,
      accent: next.accent ?? accent,
    };
    if (next.curriculum) setCurriculum(next.curriculum);
    if (next.accent) setAccent(next.accent);
    onSave(config);
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1800);
  };

  return (
    <div className="h-full overflow-y-auto px-5 pb-10">
      {/* 顶部导航 */}
      <div className="flex items-center gap-3 pt-8">
        <button
          type="button"
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-full text-[#888780] transition-colors active:bg-[#F1EFE8]"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M19 12H5" />
            <path d="M12 19l-7-7 7-7" />
          </svg>
        </button>
        <h1 className="text-lg font-medium">设置</h1>
        <div className="ml-auto flex items-center gap-2">
          {saved && (
            <span className="animate-[fadeIn_.2s_ease] rounded-full bg-[#E1F5EE] px-3 py-1 text-xs font-medium text-[#0F6E56]">
              ✓ 已保存
            </span>
          )}
          <div
            className="flex h-8 w-8 items-center justify-center rounded-full border border-black/5 text-base"
            style={{ backgroundColor: avatar.color }}
          >
            {avatar.emoji}
          </div>
        </div>
      </div>

      {/* 教材版本 */}
      <h2 className="mt-7 mb-1 text-sm font-medium text-[#444441]">
        教材版本
      </h2>
      <p className="text-xs text-[#888780]">
        学习进度按教材分开保存，切换教材互不影响
      </p>
      <div className="mt-3 flex flex-col gap-2.5">
        {VERSIONS.map((v) => {
          const active = curriculum === v;
          return (
            <button
              key={v}
              type="button"
              onClick={() => commit({ curriculum: v })}
              className={`flex items-center justify-between rounded-xl border px-4 py-3.5 text-left transition-all active:scale-[0.98] ${
                active
                  ? "border-[#534AB7] bg-[#F4F2FF] shadow-sm"
                  : "border-[#E5E4E0] bg-white"
              }`}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-[#2C2C2A]">
                    {CURRICULUM_LABELS[v]}
                  </span>
                  {active && (
                    <span className="rounded-full bg-[#534AB7] px-2 py-0.5 text-[10px] font-medium text-white">
                      当前
                    </span>
                  )}
                </div>
                <p className="mt-1 text-[11px] leading-4 text-[#888780]">
                  {CURRICULUM_DESC[v]}
                </p>
                <p className="mt-0.5 text-[11px] text-[#B4B2A9]">
                  {stats[v].units} 个单元 · {stats[v].entries} 个词条
                </p>
              </div>
              <span
                className={`ml-3 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border-2 ${
                  active
                    ? "border-[#534AB7] bg-[#534AB7]"
                    : "border-[#D3D1C7] bg-white"
                }`}
              >
                {active && (
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M20 6L9 17l-5-5" />
                  </svg>
                )}
              </span>
            </button>
          );
        })}
      </div>

      {/* 发音口音 */}
      <h2 className="mt-8 mb-1 text-sm font-medium text-[#444441]">
        发音口音
      </h2>
      <p className="text-xs text-[#888780]">
        影响单词与句子的朗读音色
      </p>
      <div className="mt-3 grid grid-cols-2 gap-2.5">
        {ACCENTS.map((a) => {
          const active = accent === a.id;
          return (
            <button
              key={a.id}
              type="button"
              onClick={() => commit({ accent: a.id })}
              className={`rounded-xl border px-4 py-4 text-center transition-all active:scale-[0.98] ${
                active
                  ? "border-[#534AB7] bg-[#F4F2FF] shadow-sm"
                  : "border-[#E5E4E0] bg-white"
              }`}
            >
              <span className="text-xl">
                {a.id === "us" ? "🇺🇸" : "🇬🇧"}
              </span>
              <p className="mt-1.5 text-sm font-medium text-[#2C2C2A]">
                {a.label}
              </p>
              <p className="mt-0.5 text-[11px] text-[#888780]">{a.desc}</p>
            </button>
          );
        })}
      </div>

      {/* 说明 */}
      <div className="mt-8 rounded-xl border border-[#E8E6E0] bg-white p-4">
        <p className="text-xs leading-5 text-[#888780]">
          💡 使用说明：切换教材后，该教材的学习进度会从第一单元开始，
          之前在其他教材上的进度仍然保留。
        </p>
      </div>
    </div>
  );
}
